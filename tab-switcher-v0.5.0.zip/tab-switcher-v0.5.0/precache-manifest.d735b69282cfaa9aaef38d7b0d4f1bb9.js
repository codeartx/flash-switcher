self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e788d193f322493c6d5c7e0d88f34f70",
    "url": "/index.html"
  },
  {
    "revision": "7547ad8b99d9a4213287",
    "url": "/static/css/content.css"
  },
  {
    "revision": "5ddc531268aba77fa4a0",
    "url": "/static/css/main.css"
  },
  {
    "revision": "1e94107bdbacc6d591a9",
    "url": "/static/js/background.js"
  },
  {
    "revision": "7547ad8b99d9a4213287",
    "url": "/static/js/content.js"
  },
  {
    "revision": "72127b9e60abc3f9d5620023c59c7f6b",
    "url": "/static/js/content.js.LICENSE.txt"
  },
  {
    "revision": "5ddc531268aba77fa4a0",
    "url": "/static/js/main.js"
  },
  {
    "revision": "72127b9e60abc3f9d5620023c59c7f6b",
    "url": "/static/js/main.js.LICENSE.txt"
  },
  {
    "revision": "d47b6dc1dd395cffe2a446eac56b1e37",
    "url": "/static/media/Tabs.d47b6dc1.svg"
  },
  {
    "revision": "dbe67e86602508c55a8d9278568c9079",
    "url": "/static/media/carrot.dbe67e86.svg"
  }
]);